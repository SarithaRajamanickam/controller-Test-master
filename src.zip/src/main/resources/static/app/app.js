(function() {
	'use strict';
	angular.module('mainApp', [ 'ui.router' ]);
})();